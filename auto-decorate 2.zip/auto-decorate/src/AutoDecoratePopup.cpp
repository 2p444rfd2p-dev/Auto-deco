#include "AutoDecoratePopup.hpp"
#include <Geode/utils/cocos.hpp>

using namespace geode::prelude;
using namespace autodec;

AutoDecoratePopup* AutoDecoratePopup::create(EditorUI* ui) {
	auto ret = new AutoDecoratePopup();
	if (ret->initAnchored(380.f, 280.f, ui)) {
		ret->autorelease();
		return ret;
	}
	CC_SAFE_DELETE(ret);
	return nullptr;
}

bool AutoDecoratePopup::setup(EditorUI* ui) {
	m_editorUI = ui;
	this->setTitle("Auto Decorate");

	auto size = m_mainLayer->getContentSize();
	float cx = size.width / 2.f;

	// restore last theme
	int saved = Mod::get()->getSavedValue<int>("last-theme", 0);
	m_settings.theme = static_cast<Theme>(std::clamp(saved, 0, 4));
	m_settings.fps = std::clamp(GameManager::get()->m_customFPSTarget > 0
		? static_cast<int>(GameManager::get()->m_customFPSTarget) : 60, 30, 360);

	// ----- Theme label + buttons -----
	auto themeLabel = CCLabelBMFont::create("Theme", "goldFont.fnt");
	themeLabel->setScale(0.6f);
	themeLabel->setPosition({ cx, size.height - 50.f });
	m_mainLayer->addChild(themeLabel);

	auto themeMenu = CCMenu::create();
	themeMenu->setPosition({ 0, 0 });
	themeMenu->setContentSize(size);
	m_mainLayer->addChild(themeMenu);

	const char* names[5] = { "Forest", "Bloodbath", "Tsunami", "Amethyst", "Pulse" };
	// row 1: 3 buttons, row 2: 2 buttons
	float xs[5] = { cx - 100.f, cx, cx + 100.f, cx - 50.f, cx + 50.f };
	float ys[5] = { size.height - 82.f, size.height - 82.f, size.height - 82.f,
	                size.height - 118.f, size.height - 118.f };
	for (int i = 0; i < 5; i++) {
		auto spr = ButtonSprite::create(names[i], 90, true, "bigFont.fnt", "GJ_button_01.png", 28.f, 0.55f);
		auto btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(AutoDecoratePopup::onTheme));
		btn->setTag(i);
		btn->setPosition({ xs[i], ys[i] });
		themeMenu->addChild(btn);
		m_themeButtons.push_back(btn);
	}
	this->refreshThemeButtons();

	// ----- 3D toggle -----
	auto toggleMenu = CCMenu::create();
	toggleMenu->setPosition({ 0, 0 });
	toggleMenu->setContentSize(size);
	m_mainLayer->addChild(toggleMenu);

	m_3dToggle = CCMenuItemToggler::createWithStandardSprites(
		this, menu_selector(AutoDecoratePopup::on3D), 0.7f);
	m_3dToggle->setPosition({ cx - 60.f, size.height - 160.f });
	m_3dToggle->toggle(false);
	toggleMenu->addChild(m_3dToggle);

	auto label3D = CCLabelBMFont::create("3D", "bigFont.fnt");
	label3D->setScale(0.7f);
	label3D->setAnchorPoint({ 0.f, 0.5f });
	label3D->setPosition({ cx - 35.f, size.height - 160.f });
	m_mainLayer->addChild(label3D);

	auto hint3D = CCLabelBMFont::create("(adds depth layers, uses more objects)", "chatFont.fnt");
	hint3D->setScale(0.5f);
	hint3D->setOpacity(160);
	hint3D->setPosition({ cx, size.height - 180.f });
	m_mainLayer->addChild(hint3D);

	// ----- FPS -----
	auto fpsLabel = CCLabelBMFont::create("Your FPS", "goldFont.fnt");
	fpsLabel->setScale(0.55f);
	fpsLabel->setPosition({ cx - 110.f, size.height - 210.f });
	m_mainLayer->addChild(fpsLabel);

	m_fpsInput = TextInput::create(70.f, "FPS", "bigFont.fnt");
	m_fpsInput->setFilter("0123456789");
	m_fpsInput->setMaxCharCount(3);
	m_fpsInput->setString(std::to_string(m_settings.fps));
	m_fpsInput->setPosition({ cx - 50.f, size.height - 210.f });
	m_mainLayer->addChild(m_fpsInput);

	int presets[3] = { 60, 120, 240 };
	for (int i = 0; i < 3; i++) {
		auto spr = ButtonSprite::create(std::to_string(presets[i]).c_str(), 40, true,
			"bigFont.fnt", "GJ_button_04.png", 24.f, 0.5f);
		auto btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(AutoDecoratePopup::onFpsPreset));
		btn->setTag(presets[i]);
		btn->setPosition({ cx + 25.f + i * 48.f, size.height - 210.f });
		toggleMenu->addChild(btn);
	}

	auto fpsHint = CCLabelBMFont::create("60 = low object count   |   240 = high object count", "chatFont.fnt");
	fpsHint->setScale(0.5f);
	fpsHint->setOpacity(160);
	fpsHint->setPosition({ cx, size.height - 232.f });
	m_mainLayer->addChild(fpsHint);

	// ----- Decorate -----
	auto goSpr = ButtonSprite::create("Decorate!", 120, true, "goldFont.fnt", "GJ_button_01.png", 32.f, 0.8f);
	auto goBtn = CCMenuItemSpriteExtra::create(goSpr, this, menu_selector(AutoDecoratePopup::onDecorate));
	goBtn->setPosition({ cx, 26.f });
	toggleMenu->addChild(goBtn);

	return true;
}

void AutoDecoratePopup::refreshThemeButtons() {
	for (size_t i = 0; i < m_themeButtons.size(); i++) {
		auto spr = static_cast<ButtonSprite*>(m_themeButtons[i]->getNormalImage());
		bool sel = static_cast<int>(i) == static_cast<int>(m_settings.theme);
		spr->updateBGImage(sel ? "GJ_button_02.png" : "GJ_button_01.png");
	}
}

void AutoDecoratePopup::onTheme(CCObject* sender) {
	m_settings.theme = static_cast<Theme>(static_cast<CCNode*>(sender)->getTag());
	Mod::get()->setSavedValue<int>("last-theme", static_cast<CCNode*>(sender)->getTag());
	this->refreshThemeButtons();
}

void AutoDecoratePopup::onFpsPreset(CCObject* sender) {
	int fps = static_cast<CCNode*>(sender)->getTag();
	m_fpsInput->setString(std::to_string(fps));
}

void AutoDecoratePopup::on3D(CCObject*) {
	// toggler state flips after the callback fires, so invert
	m_settings.is3D = !m_3dToggle->isToggled();
}

void AutoDecoratePopup::onDecorate(CCObject*) {
	// parse FPS
	int fps = 60;
	auto str = m_fpsInput->getString();
	if (!str.empty()) {
		auto parsed = geode::utils::numFromString<int>(str);
		if (parsed.isOk()) fps = parsed.unwrap();
	}
	m_settings.fps = std::clamp(fps, 30, 360);
	m_settings.is3D = m_3dToggle->isToggled();

	auto lel = m_editorUI->m_editorLayer;
	int count = decorate(lel, m_settings);

	if (m_editorUI) m_editorUI->updateButtons();

	Notification::create(
		fmt::format("{} decoration: {} objects added", themeName(m_settings.theme), count),
		NotificationIcon::Success
	)->show();

	this->onClose(nullptr);
}
