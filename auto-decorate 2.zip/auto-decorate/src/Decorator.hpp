#pragma once
#include <Geode/Geode.hpp>

namespace autodec {

enum class Theme { Forest = 0, Bloodbath, Tsunami, Amethyst, Pulse };

struct Settings {
	Theme theme = Theme::Forest;
	bool is3D = false;
	int fps = 60;
};

const char* themeName(Theme t);

// Returns number of objects generated (including triggers)
int decorate(LevelEditorLayer* lel, Settings const& s);

}
