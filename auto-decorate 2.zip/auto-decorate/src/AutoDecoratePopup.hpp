#pragma once
#include <Geode/Geode.hpp>
#include "Decorator.hpp"

class AutoDecoratePopup : public geode::Popup<EditorUI*> {
protected:
	EditorUI* m_editorUI = nullptr;
	autodec::Settings m_settings;
	std::vector<CCMenuItemSpriteExtra*> m_themeButtons;
	CCMenuItemToggler* m_3dToggle = nullptr;
	geode::TextInput* m_fpsInput = nullptr;

	bool setup(EditorUI* ui) override;
	void refreshThemeButtons();
	void onTheme(cocos2d::CCObject* sender);
	void onFpsPreset(cocos2d::CCObject* sender);
	void on3D(cocos2d::CCObject* sender);
	void onDecorate(cocos2d::CCObject* sender);

public:
	static AutoDecoratePopup* create(EditorUI* ui);
};
