#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>
#include "AutoDecoratePopup.hpp"

using namespace geode::prelude;

class $modify(ADEditorUI, EditorUI) {
	bool init(LevelEditorLayer* lel) {
		if (!EditorUI::init(lel)) return false;

		// Find the menu that holds the playtest button
		CCNode* menu = this->getChildByID("playtest-menu");
		if (!menu) menu = this->getChildByID("playback-menu");
		if (!menu && m_playtestBtn) menu = m_playtestBtn->getParent();
		if (!menu) {
			log::warn("Auto Decorate: could not find playtest menu");
			return true;
		}

		auto spr = ButtonSprite::create("AD", 30, true, "bigFont.fnt", "GJ_button_01.png", 30.f, 0.7f);
		spr->setScale(0.8f);
		auto btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(ADEditorUI::onAutoDecorate));
		btn->setID("auto-decorate-button"_spr);
		menu->addChild(btn);

		if (menu->getLayout()) {
			menu->updateLayout();
		} else if (m_playtestBtn) {
			// no layout on this menu: place it just beside the playtest button
			auto p = m_playtestBtn->getPosition();
			btn->setPosition({ p.x + 40.f, p.y });
		}
		return true;
	}

	void onAutoDecorate(CCObject*) {
		AutoDecoratePopup::create(this)->show();
	}
};
