#include "Decorator.hpp"
#include <random>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <vector>

using namespace geode::prelude;

namespace autodec {

const char* themeName(Theme t) {
	switch (t) {
		case Theme::Forest: return "Forest";
		case Theme::Bloodbath: return "Bloodbath";
		case Theme::Tsunami: return "Tsunami";
		case Theme::Amethyst: return "Amethyst";
		case Theme::Pulse: return "Pulse";
	}
	return "?";
}

namespace {

// Color channels used by the generated decoration
constexpr int CH_BASE1 = 990;
constexpr int CH_BASE2 = 991;
constexpr int CH_ACCENT = 992;
constexpr int CH_GLOW = 993;
constexpr int CH_SHADOW = 994;

// Special channels
constexpr int CH_BG = 1000;
constexpr int CH_G1 = 1001;
constexpr int CH_G2 = 1009;

// Object IDs
constexpr int ID_BLOCK = 1;
constexpr int ID_SPIKE = 8;
constexpr int ID_SMALL_SPIKE = 39;
constexpr int ID_COLOR_TRIGGER = 899;
constexpr int ID_PULSE_TRIGGER = 1006;

constexpr float GROUND_Y = 15.f;     // centre of a 1x1 block sitting on the ground
constexpr float SCREEN_W = 570.f;    // approx. visible editor units horizontally
constexpr float TRIGGER_Y = 345.f;

struct RGB { int r, g, b; };

struct Palette {
	RGB base1, base2, accent, glow, bg, ground;
};

RGB hsv(float h, float s, float v) {
	h = std::fmod(h, 360.f);
	if (h < 0) h += 360.f;
	float c = v * s;
	float x = c * (1 - std::fabs(std::fmod(h / 60.f, 2.f) - 1));
	float m = v - c;
	float r = 0, g = 0, b = 0;
	if (h < 60) { r = c; g = x; }
	else if (h < 120) { r = x; g = c; }
	else if (h < 180) { g = c; b = x; }
	else if (h < 240) { g = x; b = c; }
	else if (h < 300) { r = x; b = c; }
	else { r = c; b = x; }
	return { int((r + m) * 255), int((g + m) * 255), int((b + m) * 255) };
}

RGB darken(RGB c, float f) {
	return { int(c.r * f), int(c.g * f), int(c.b * f) };
}

Palette paletteFor(Theme t) {
	switch (t) {
		case Theme::Forest:
			return { {34,139,34}, {0,100,60}, {154,205,50}, {200,255,150}, {8,25,12}, {5,40,15} };
		case Theme::Bloodbath:
			return { {140,0,0}, {200,20,20}, {255,60,40}, {255,160,140}, {25,0,0}, {45,0,0} };
		case Theme::Tsunami:
			return { {0,119,190}, {0,180,216}, {144,224,239}, {255,255,255}, {2,15,40}, {0,60,100} };
		case Theme::Amethyst:
			return { {153,102,204}, {106,13,173}, {224,176,255}, {255,230,255}, {15,5,30}, {40,10,70} };
		case Theme::Pulse:
		default:
			return { hsv(0,1,1), hsv(120,1,1), hsv(240,1,1), hsv(300,.4f,1), {10,10,20}, {20,20,40} };
	}
}

struct Obj {
	int id;
	float x, y;
	float sx = 1.f, sy = 1.f;
	float rot = 0.f;
	int channel = CH_BASE1;
	bool flat = false; // flat = no 3D layering (e.g. glow dots)
};

struct Budget {
	float step;       // horizontal distance between columns
	int maxObjects;
};

Budget computeBudget(int fps, bool is3D, float levelLen) {
	fps = std::clamp(fps, 30, 360);
	// Objects per screen width: 60fps ~ 8, 120fps ~ 16, 240fps ~ 28
	float perScreen = std::clamp(4.f + (fps - 30) * 0.115f, 4.f, 40.f);
	float step = SCREEN_W / perScreen;
	// Hard cap on total objects so the game doesn't lag
	int maxObjects = std::clamp(fps * 35, 800, 12000);
	float objsPerColumn = 2.2f * (is3D ? 3.f : 1.f);
	float neededStep = levelLen * objsPerColumn / float(maxObjects);
	step = std::max(step, neededStep);
	return { step, maxObjects };
}

// ---------- serialization ----------

void emitObject(std::ostringstream& out, int id, float x, float y, int channel,
                float sx, float sy, float rot, int zLayer, int zOrder) {
	out << "1," << id
	    << ",2," << x
	    << ",3," << y
	    << ",21," << channel
	    << ",24," << zLayer
	    << ",25," << zOrder
	    << ",121,1"   // no touch (never affects gameplay)
	    << ",103,1";  // high detail
	if (rot != 0.f) out << ",6," << rot;
	if (sx != 1.f) out << ",128," << sx;
	if (sy != 1.f) out << ",129," << sy;
	out << ";";
}

void emitDeco(std::ostringstream& out, Obj const& o, bool is3D, int& count) {
	if (is3D && !o.flat) {
		float depth = 4.f * std::max(o.sx, o.sy) + 3.f;
		// shadow (behind, offset down-right)
		emitObject(out, o.id, o.x + depth, o.y - depth, CH_SHADOW, o.sx, o.sy, o.rot, 1, -2);
		// main body
		emitObject(out, o.id, o.x, o.y, o.channel, o.sx, o.sy, o.rot, 3, 0);
		// highlight (in front, small, offset up-left)
		emitObject(out, o.id, o.x - depth * 0.4f, o.y + depth * 0.4f, CH_GLOW, o.sx * 0.55f, o.sy * 0.55f, o.rot, 3, 2);
		count += 3;
	} else {
		emitObject(out, o.id, o.x, o.y, o.channel, o.sx, o.sy, o.rot, 3, 0);
		count += 1;
	}
}

void emitColorTrigger(std::ostringstream& out, float x, float y, int channel, RGB c, float duration) {
	out << "1," << ID_COLOR_TRIGGER
	    << ",2," << x << ",3," << y
	    << ",7," << c.r << ",8," << c.g << ",9," << c.b
	    << ",10," << duration
	    << ",23," << channel
	    << ",35,1"
	    << ";";
}

void emitPulseTrigger(std::ostringstream& out, float x, float y, int channel, RGB c,
                      float fadeIn, float hold, float fadeOut) {
	out << "1," << ID_PULSE_TRIGGER
	    << ",2," << x << ",3," << y
	    << ",7," << c.r << ",8," << c.g << ",9," << c.b
	    << ",45," << fadeIn
	    << ",46," << hold
	    << ",47," << fadeOut
	    << ",51," << channel
	    << ",52,0"   // color mode
	    << ",49,0"   // not HSV
	    << ";";
}

// ---------- theme column generators ----------

template <class Rng>
float rnd(Rng& g, float a, float b) {
	return std::uniform_real_distribution<float>(a, b)(g);
}

template <class Rng>
void genColumn(Theme t, float x, Rng& g, std::vector<Obj>& v) {
	switch (t) {
		case Theme::Forest: {
			// Tree trunk
			if (rnd(g, 0, 1) < 0.35f) {
				float sy = rnd(g, 2.f, 6.f);
				v.push_back({ ID_BLOCK, x, GROUND_Y * sy / 1.f * 1.0f, 0.4f, sy, 0.f, CH_BASE2 });
				// leafy crown (big rotated squares)
				float cs = rnd(g, 1.5f, 3.f);
				v.push_back({ ID_BLOCK, x, 30.f * sy + 10.f, cs, cs * 0.8f, 45.f, CH_BASE1 });
			}
			// Grass
			v.push_back({ ID_SMALL_SPIKE, x + rnd(g, -10, 10), GROUND_Y - 4.f, rnd(g, .6f, 1.4f), rnd(g, .8f, 1.8f), 0.f, CH_ACCENT });
			// Falling leaves / fireflies
			if (rnd(g, 0, 1) < 0.5f)
				v.push_back({ ID_BLOCK, x + rnd(g, -30, 30), rnd(g, 60, 300), 0.2f, 0.2f, rnd(g, 0, 90), CH_GLOW, true });
			break;
		}
		case Theme::Bloodbath: {
			// Jagged blood spikes rising from the ground
			float h = rnd(g, 1.f, 3.2f);
			v.push_back({ ID_SPIKE, x, GROUND_Y + 15.f * h - 15.f, rnd(g, .6f, 1.2f), h, 0.f, CH_BASE1 });
			if (rnd(g, 0, 1) < 0.4f)
				v.push_back({ ID_SPIKE, x + 18.f, GROUND_Y + 10.f, 0.7f, rnd(g, .5f, 1.5f), rnd(g, -12, 12), CH_BASE2 });
			// Blood drops
			if (rnd(g, 0, 1) < 0.55f)
				v.push_back({ ID_BLOCK, x + rnd(g, -25, 25), rnd(g, 80, 300), 0.18f, rnd(g, .3f, .7f), 0.f, CH_ACCENT, true });
			// Gore pools on the ground
			if (rnd(g, 0, 1) < 0.25f)
				v.push_back({ ID_BLOCK, x, 4.f, rnd(g, 1.5f, 3.5f), 0.3f, 0.f, CH_BASE2 });
			break;
		}
		case Theme::Tsunami: {
			// Rolling wave columns (sine heights)
			float wave = 0.5f + 0.5f * std::sin(x / 140.f);
			float h = 1.f + wave * 4.f;
			v.push_back({ ID_BLOCK, x, 30.f * h * 0.5f, 0.9f, h, 0.f, CH_BASE1 });
			v.push_back({ ID_BLOCK, x, 30.f * h + 6.f, 0.9f, 0.4f, 0.f, CH_ACCENT });   // foam crest
			// Bubbles
			if (rnd(g, 0, 1) < 0.5f) {
				float s = rnd(g, .2f, .5f);
				v.push_back({ ID_BLOCK, x + rnd(g, -20, 20), rnd(g, 90, 300), s, s, 45.f, CH_GLOW, true });
			}
			break;
		}
		case Theme::Amethyst: {
			// Crystal clusters
			int n = (rnd(g, 0, 1) < 0.5f) ? 3 : 2;
			for (int i = 0; i < n; i++) {
				float h = rnd(g, .8f, 3.f);
				float rot = rnd(g, -25, 25);
				v.push_back({ ID_SPIKE, x + i * 14.f - 14.f, GROUND_Y + 15.f * h - 15.f, rnd(g, .5f, 1.f), h, rot,
				              (i % 2) ? CH_BASE2 : CH_BASE1 });
			}
			// Floating shards
			if (rnd(g, 0, 1) < 0.5f)
				v.push_back({ ID_SPIKE, x + rnd(g, -20, 20), rnd(g, 90, 300), 0.4f, rnd(g, .5f, 1.2f), rnd(g, 0, 360), CH_ACCENT, true });
			break;
		}
		case Theme::Pulse:
		default: {
			// Neon squares & spikes floating everywhere
			float s = rnd(g, .3f, 1.4f);
			int chs[3] = { CH_BASE1, CH_BASE2, CH_ACCENT };
			v.push_back({ (rnd(g, 0, 1) < 0.7f) ? ID_BLOCK : ID_SPIKE, x + rnd(g, -20, 20), rnd(g, 20, 300), s, s, rnd(g, 0, 90), chs[int(rnd(g, 0, 2.99f))] });
			v.push_back({ ID_BLOCK, x, GROUND_Y - 4.f, 1.f, 0.3f, 0.f, CH_GLOW, true });
			break;
		}
	}
}

} // namespace

int decorate(LevelEditorLayer* lel, Settings const& s) {
	if (!lel) return 0;

	// Determine level length from existing objects
	float levelLen = 0.f;
	for (auto obj : CCArrayExt<GameObject*>(lel->m_objects)) {
		levelLen = std::max(levelLen, obj->getPositionX());
	}
	levelLen = std::max(levelLen + 300.f, 3000.f);

	auto pal = paletteFor(s.theme);
	auto budget = computeBudget(s.fps, s.is3D, levelLen);

	std::mt19937 rng(static_cast<unsigned>(std::random_device{}()));
	int total = 0;

	std::vector<std::string> chunks;
	std::ostringstream cur;
	int chunkCount = 0;
	auto flushIfBig = [&](bool force = false) {
		if (force || chunkCount > 400) {
			if (chunkCount > 0) chunks.push_back(cur.str());
			cur.str("");
			cur.clear();
			chunkCount = 0;
		}
	};

	// 1) Color triggers at the start of the level
	emitColorTrigger(cur, 0.f, TRIGGER_Y, CH_BASE1, pal.base1, 0.f);
	emitColorTrigger(cur, 0.f, TRIGGER_Y + 30.f, CH_BASE2, pal.base2, 0.f);
	emitColorTrigger(cur, 0.f, TRIGGER_Y + 60.f, CH_ACCENT, pal.accent, 0.f);
	emitColorTrigger(cur, 0.f, TRIGGER_Y + 90.f, CH_GLOW, pal.glow, 0.f);
	emitColorTrigger(cur, 0.f, TRIGGER_Y + 120.f, CH_SHADOW, darken(pal.base1, 0.3f), 0.f);
	emitColorTrigger(cur, 0.f, TRIGGER_Y + 150.f, CH_BG, pal.bg, 0.f);
	emitColorTrigger(cur, 0.f, TRIGGER_Y + 180.f, CH_G1, pal.ground, 0.f);
	emitColorTrigger(cur, 0.f, TRIGGER_Y + 210.f, CH_G2, pal.ground, 0.f);
	chunkCount += 8;
	total += 8;

	// 2) Pulse / color-cycling triggers
	if (s.theme == Theme::Pulse) {
		float hue = 0.f;
		for (float x = 60.f; x < levelLen; x += 100.f) {
			hue += 47.f;
			emitPulseTrigger(cur, x, TRIGGER_Y + 30.f * (int(x / 100.f) % 3), CH_BASE1, hsv(hue, 1, 1), 0.05f, 0.1f, 0.35f);
			emitPulseTrigger(cur, x + 5.f, TRIGGER_Y + 30.f * (int(x / 100.f) % 3) + 10.f, CH_BASE2, hsv(hue + 120.f, 1, 1), 0.05f, 0.1f, 0.35f);
			emitPulseTrigger(cur, x + 10.f, TRIGGER_Y + 30.f * (int(x / 100.f) % 3) + 20.f, CH_ACCENT, hsv(hue + 240.f, 1, 1), 0.05f, 0.1f, 0.35f);
			if (int(x / 100.f) % 4 == 0) {
				emitColorTrigger(cur, x + 15.f, TRIGGER_Y + 240.f, CH_BG, hsv(hue, 0.8f, 0.18f), 0.6f);
				chunkCount++; total++;
			}
			chunkCount += 3; total += 3;
			flushIfBig();
		}
	} else {
		// Gentle beat pulse on the accent colour
		for (float x = 120.f; x < levelLen; x += 240.f) {
			emitPulseTrigger(cur, x, TRIGGER_Y + 240.f, CH_ACCENT, pal.glow, 0.05f, 0.05f, 0.4f);
			chunkCount++; total++;
			flushIfBig();
		}
	}

	// 3) Decoration objects
	std::vector<Obj> col;
	for (float x = 0.f; x < levelLen && total < budget.maxObjects; x += budget.step) {
		col.clear();
		genColumn(s.theme, x, rng, col);
		for (auto const& o : col) {
			int before = total;
			int added = 0;
			emitDeco(cur, o, s.is3D, added);
			total += added;
			chunkCount += total - before;
			flushIfBig();
		}
	}
	flushIfBig(true);

	// 4) Push everything into the editor
	for (auto const& c : chunks) {
		lel->createObjectsFromString(c, true, true);
	}

	return total;
}

} // namespace autodec
