# Auto Decorate

Open the editor and press the **AD** button next to the playtest button.

- Pick a theme: **Forest**, **Bloodbath**, **Tsunami**, **Amethyst** or **Pulse**
- Toggle **3D** for layered shadow/highlight depth
- Enter your **FPS** (60 = fewer objects, 240 = lots of objects)
- Press **Decorate!**

All decoration objects are *no-touch* and *high detail*, so they never affect gameplay.
Use the editor's undo (Ctrl+Z) to remove a generation.
