# Auto Decorate (Geode mod for Geometry Dash 2.2074)

**Platforms:** Windows (PC), macOS, Android (32 + 64 bit) and iOS (iPhone/iPad). One `.geode` file built by the workflow contains all of them.

Open the editor -> press **AD** next to the playtest button -> choose theme, 3D on/off, your FPS -> **Decorate!**

Themes: Forest, Bloodbath, Tsunami, Amethyst, Pulse.
Object count scales with FPS (60 = low, 240 = high) with a hard cap so levels don't lag.
Everything generated is no-touch + high-detail, so gameplay is never affected. Undo with Ctrl+Z.
Colors are applied by color triggers at X=0, so they show up when you playtest.

## Getting the .geode file (pick ONE)

### A) GitHub Actions (no installs, easiest)
1. Create a free GitHub repo and upload everything in this folder.
2. Open the **Actions** tab -> the "Build Geode Mod" workflow runs automatically.
3. When it finishes, download the **Build Output** artifact. Inside is `yourname.auto-decorate.geode`.
4. Put it in `Geometry Dash/geode/mods/` (or use Geode's "Install mod from file").

### B) Build locally (Windows)
1. Install Geode CLI + SDK: https://docs.geode-sdk.org/getting-started/geode-cli
2. `geode sdk install` then `geode sdk install-binaries`
3. In this folder: `geode build`
4. The `.geode` file appears in `build/`.

Before publishing, change `yourname` in mod.json (id + developer).

## Installing on each platform
- **PC (Windows):** install Geode, then put the `.geode` in `Geometry Dash/geode/mods/` or use Geode's in-game *Install from file*.
- **Android:** install the Geode launcher, then copy the `.geode` to `Android/media/com.geode.launcher/game/geode/mods/` (or install via the Geode menu).
- **iPhone/iPad:** requires a Geode-enabled GD install (e.g. via the Geode iOS launcher/sideload). Put the `.geode` in the app's `geode/mods` folder, or install from file in Geode.

The UI uses on-screen buttons only (no keyboard needed except the FPS box, which also has 60/120/240 tap buttons), so it works with touch.

## "Invalid Geode mod" error?
A `.geode` file is NOT this zip renamed. It is a compiled package (contains the built `.dll`/`.so`/`.dylib` plus mod.json and logo). Renaming `auto-decorate.zip` to `.geode` will always show "invalid mod". You must build it (GitHub Actions or `geode build`) and use the file that comes out.
Also make sure the built file name matches the mod id in mod.json, e.g. `yourname.auto-decorate.geode`.
